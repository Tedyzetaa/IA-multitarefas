"use client";

import { useCallback, useState } from "react";
import { processAudioDubbing } from "@/lib/nexusBridge";
import { toast } from "@/lib/toast";
import {
  AudioDubbingResult,
  AudioDubbingSettings,
  AudioDubbingStatus,
} from "@/lib/types";

export function useAudioDubbing() {
  const [status, setStatus] = useState<AudioDubbingStatus>("idle");
  const [progress, setProgress] = useState(0);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<AudioDubbingResult | null>(null);

  const reset = useCallback(() => {
    setStatus("idle");
    setProgress(0);
    setError(null);
    setResult(null);
  }, []);

  const process = useCallback(
    async (file: File, settings: AudioDubbingSettings) => {
      setIsProcessing(true);
      setStatus("uploading");
      setProgress(12);
      setError(null);

      try {
        setStatus("processing");
        setProgress(38);

        const response = await processAudioDubbing(file, settings);

        if (response.status === "error" || response.error) {
          throw new Error(response.error ?? "Falha na dublagem de áudio.");
        }

        setStatus(response.status);
        setProgress(response.progress ?? 100);
        setResult(response);

        if (response.status === "success") {
          toast("Dublagem concluída com sucesso.", "success");
        } else {
          toast("Dublagem em andamento.", "info");
        }
      } catch (err) {
        const message =
          err instanceof Error ? err.message : "Não foi possível processar o áudio.";
        setStatus("error");
        setProgress(0);
        setError(message);
        toast(message, "error");
      } finally {
        setIsProcessing(false);
      }
    },
    []
  );

  return {
    status,
    progress,
    isProcessing,
    error,
    result,
    process,
    reset,
  };
}
