/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,

  // Proxy reverso via Next.js: o navegador so fala com a propria origem
  // (localhost:3000), e o Next.js repassa a chamada por baixo dos panos
  // para o Ollama / Nexus-Bridge reais. Isso elimina CORS e requisicoes
  // OPTIONS de preflight por completo -- em vez de "consertar" headers,
  // a chamada deixa de ser cross-origin.
  //
  // Configure OLLAMA_INTERNAL_URL / NEXUS_INTERNAL_URL no .env se os
  // serviços não estiverem nos endereços padrão abaixo.
  async rewrites() {
    return [
      {
        source: "/ollama-proxy/:path*",
        destination: `${process.env.OLLAMA_INTERNAL_URL || "http://127.0.0.1:11434"}/:path*`,
      },
      {
        source: "/nexus-proxy/:path*",
        destination: `${process.env.NEXUS_INTERNAL_URL || "http://127.0.0.1:8000"}/:path*`,
      },
    ];
  },
  allowedDevOrigins: ["100.113.248.34", "localhost:3000"],
};

module.exports = nextConfig;
